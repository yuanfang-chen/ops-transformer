/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file matrix_transform_rope_v2.cpp
 * \brief 算子Kernel实现文件
 */

#include "matrix_transform_rope_v2.h"
#include "kernel_operator.h"

using namespace AscendC;
using namespace MatrixTransformRopeV2;

extern "C" __global__ __aicore__ void matrix_transform_rope_v2(GM_ADDR x, GM_ADDR cos, GM_ADDR sin,
                                                             GM_ADDR rotate, GM_ADDR out,
                                                             GM_ADDR workspace, GM_ADDR tiling) {
    MatrixTransformRopeV2TilingData *tilingData = reinterpret_cast<MatrixTransformRopeV2TilingData *>(tiling);

    InitParams initParams;
    initParams.x = x;
    initParams.cos = cos;
    initParams.sin = sin;
    initParams.rotate = rotate;
    initParams.out = out;
    initParams.workspace = workspace;
    initParams.tilingData = tilingData;
    initParams.tPipeIn = &GetTilingPipe();

    // 根据数据类型创建Kernel实例
    // TODO: 根据实际数据类型选择合适的Kernel
    // 例如：MatrixTransformRopeV2Kernel<half_t> kernel;
    // kernel.Init(initParams);
    // kernel.Process();
}
