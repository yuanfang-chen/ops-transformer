/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/* !
 * \file matrix_transform_rope_v2_infershape.cpp
 * \brief 算子形状推导实现
 */
#include <map>
#include <string>
#include <sstream>
#include <initializer_list>

#include "exe_graph/runtime/infer_shape_context.h"
#include "exe_graph/runtime/shape.h"
#include "exe_graph/runtime/storage_shape.h"
#include "register/op_impl_registry.h"
#include "log/log.h"
#include "../../../common/include/err/ops_err.h"

using namespace gert;
using namespace ge;

namespace ops {

const constexpr int64_t INPUT_X_INDEX = 0;
const constexpr int64_t INPUT_COS_INDEX = 1;
const constexpr int64_t INPUT_SIN_INDEX = 2;
const constexpr int64_t INPUT_ROTATE_INDEX = 3;
const constexpr int64_t OUTPUT_OUT_INDEX = 0;

/**
 * @brief 形状推导函数
 * 输出shape与输入x保持一致
 */
static ge::graphStatus InferShapeMatrixTransformRopeV2(InferShapeContext *context)
{
    OP_LOGD(context->GetNodeName(), "Begin to do InferShape MatrixTransformRopeV2");

    // 获取输入x的形状
    auto xShape = context->GetInputShape(INPUT_X_INDEX);
    OP_CHECK_NULL_WITH_CONTEXT(context, xShape, return GRAPH_FAILED);

    // 获取输出out的形状
    auto outShape = context->GetOutputShape(OUTPUT_OUT_INDEX);
    OP_CHECK_NULL_WITH_CONTEXT(context, outShape, return GRAPH_FAILED);

    // 设置输出的形状与x保持一致
    auto xDimNum = xShape->GetDimNum();
    outShape->SetDimNum(xDimNum);
    for (int64_t i = 0; i < xDimNum; ++i) {
        outShape->SetDim(i, xShape->GetDim(i));
    }

    OP_LOGD(context->GetNodeName(), "End to do InferShape MatrixTransformRopeV2");
    return GRAPH_SUCCESS;
}

static graphStatus InferDataTypeMatrixTransformRopeV2(gert::InferDataTypeContext *context)
{
    // 输出数据类型与输入x保持一致
    auto xType = context->GetInputDataType(INPUT_X_INDEX);
    context->SetOutputDataType(OUTPUT_OUT_INDEX, xType);

    return GRAPH_SUCCESS;
}

// 注册形状推导实现
IMPL_OP_INFERSHAPE(MatrixTransformRopeV2)
    .InferShape(InferShapeMatrixTransformRopeV2)
    .InferDataType(InferDataTypeMatrixTransformRopeV2);
} // namespace ops
