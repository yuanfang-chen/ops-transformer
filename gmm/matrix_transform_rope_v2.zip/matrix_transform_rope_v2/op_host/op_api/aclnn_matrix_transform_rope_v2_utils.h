/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef OP_HOST_OP_API_ACLNN_MATRIX_TRANSFORM_ROPE_V2_UTILS_H
#define OP_HOST_OP_API_ACLNN_MATRIX_TRANSFORM_ROPE_V2_UTILS_H

#include "aclnn_kernels/contiguous.h"
#include "acl/acl.h"
#include "aclnn/aclnn_base.h"
#include "aclnn_kernels/common/op_error_check.h"
#include "opdev/common_types.h"
#include "opdev/data_type_utils.h"
#include "opdev/format_utils.h"
#include "opdev/op_dfx.h"
#include "opdev/op_executor.h"
#include "opdev/op_log.h"
#include "opdev/platform.h"
#include "opdev/shape_utils.h"
#include "opdev/tensor_view_utils.h"
#include "opdev/make_op_executor.h"
#include "matrix_transform_rope_v2.h"

namespace matrix_transform_rope_v2 {

using namespace op;

/**
 * @brief 算子参数结构体，存储所有输入输出参数和属性
 *
 * MatrixTransformRopeV2 算子参数:
 * - x: 输入tensor，shape为[B,N,S,D]/[B,S,N,D]/[S,B,N,D]
 * - cos: 输入tensor，支持broadcast
 * - sin: 输入tensor，支持broadcast
 * - rotate: 输入tensor，shape为[D,D]
 * - out: 输出tensor，shape与x保持一致
 */
struct MatrixTransformRopeV2ParamsBase {
    // ========== 原始输入 tensor（用户传入，不可修改） ==========
    const aclTensor *x = nullptr;
    const aclTensor *cos = nullptr;
    const aclTensor *sin = nullptr;
    const aclTensor *rotate = nullptr;

    // ========== 连续格式 tensor（内部使用，指向转换后的 tensor） ==========
    const aclTensor *x_contiguous = nullptr;
    const aclTensor *cos_contiguous = nullptr;
    const aclTensor *sin_contiguous = nullptr;
    const aclTensor *rotate_contiguous = nullptr;

    // ========== 输出 tensor（用户传入，用于拷贝结果） ==========
    const aclTensor *out = nullptr;
};

/**
 * @brief Builder 类，用于构建 MatrixTransformRopeV2ParamsBase 参数结构体
 */
class MatrixTransformRopeV2ParamsBuilder {
public:
    /**
     * @brief 创建 Builder 实例
     */
    static MatrixTransformRopeV2ParamsBuilder Create(const aclTensor *x, const aclTensor *cos,
                                      const aclTensor *sin, const aclTensor *rotate,
                                      const aclTensor *out)
    {
        MatrixTransformRopeV2ParamsBuilder b;
        b.p_.x = x;
        b.p_.cos = cos;
        b.p_.sin = sin;
        b.p_.rotate = rotate;
        b.p_.out = out;
        return b;
    }

    /**
     * @brief 构建参数结构体
     */
    MatrixTransformRopeV2ParamsBase Build() const
    {
        return p_;
    }

private:
    MatrixTransformRopeV2ParamsBase p_;
};

/**
 * @brief Handler 基类，定义多 SOC 架构的通用接口
 */
class MatrixTransformRopeV2Handler {
public:
    virtual ~MatrixTransformRopeV2Handler() = default;

protected:
    /**
     * @brief 检查参数是否为 nullptr
     */
    virtual bool CheckNotNull(void)
    {
        OP_CHECK_NULL(params_.x, return false);
        OP_CHECK_NULL(params_.cos, return false);
        OP_CHECK_NULL(params_.sin, return false);
        OP_CHECK_NULL(params_.rotate, return false);
        OP_CHECK_NULL(params_.out, return false);
        return true;
    }

    /**
     * @brief 检查 tensor 是否为空
     */
    virtual bool CheckEmptyTensor(void)
    {
        if (params_.x->IsEmpty()) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "x tensor is empty");
            return false;
        }
        if (params_.cos->IsEmpty()) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "cos tensor is empty");
            return false;
        }
        if (params_.sin->IsEmpty()) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "sin tensor is empty");
            return false;
        }
        if (params_.rotate->IsEmpty()) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "rotate tensor is empty");
            return false;
        }
        return true;
    }

    /**
     * @brief 检查输入输出 tensor 的维度
     */
    virtual bool CheckInputOutDims() = 0;

    /**
     * @brief 检查输入输出 tensor 的 shape
     */
    virtual bool CheckInputOutShape() = 0;

    /**
     * @brief 检查数据类型是否有效
     */
    virtual bool CheckDtypeValid() = 0;

    /**
     * @brief 检查 format 是否支持
     */
    virtual bool CheckFormat() = 0;

    /**
     * @brief 综合参数校验
     */
    virtual aclnnStatus CheckParams()
    {
        CHECK_RET(CheckNotNull(), ACLNN_ERR_PARAM_NULLPTR);
        CHECK_RET(CheckEmptyTensor(), ACLNN_ERR_PARAM_INVALID);
        CHECK_RET(CheckInputOutDims(), ACLNN_ERR_PARAM_INVALID);
        CHECK_RET(CheckInputOutShape(), ACLNN_ERR_PARAM_INVALID);
        CHECK_RET(CheckDtypeValid(), ACLNN_ERR_PARAM_INVALID);
        CHECK_RET(CheckFormat(), ACLNN_ERR_PARAM_INVALID);
        return ACLNN_SUCCESS;
    }

    /**
     * @brief 将输入 tensor 转换为连续格式
     */
    virtual aclnnStatus ConvertDataContiguous()
    {
        params_.x_contiguous = l0op::Contiguous(params_.x, l0Executor_);
        CHECK_RET(params_.x_contiguous != nullptr, ACLNN_ERR_INNER_NULLPTR);

        params_.cos_contiguous = l0op::Contiguous(params_.cos, l0Executor_);
        CHECK_RET(params_.cos_contiguous != nullptr, ACLNN_ERR_INNER_NULLPTR);

        params_.sin_contiguous = l0op::Contiguous(params_.sin, l0Executor_);
        CHECK_RET(params_.sin_contiguous != nullptr, ACLNN_ERR_INNER_NULLPTR);

        params_.rotate_contiguous = l0op::Contiguous(params_.rotate, l0Executor_);
        CHECK_RET(params_.rotate_contiguous != nullptr, ACLNN_ERR_INNER_NULLPTR);

        return ACLNN_SUCCESS;
    }

public:
    void Initialize(const char *interfaceName, MatrixTransformRopeV2ParamsBase &params,
                  uint64_t *workspaceSize, aclOpExecutor **executor)
    {
        interfaceName_ = interfaceName;
        params_ = params;
        workspaceSize_ = workspaceSize;
        executor_ = executor;
    }

    aclnnStatus Process()
    {
        auto uniqueExecutor = CREATE_EXECUTOR();
        CHECK_RET(uniqueExecutor.get() != nullptr, ACLNN_ERR_INNER_CREATE_EXECUTOR);
        l0Executor_ = uniqueExecutor.get();

        auto ret = CheckParams();
        CHECK_RET(ret == ACLNN_SUCCESS, ret);

        if (params_.out->IsEmpty()) {
            *workspaceSize_ = 0ULL;
            uniqueExecutor.ReleaseTo(executor_);
            return ACLNN_SUCCESS;
        }

        ret = ConvertDataContiguous();
        CHECK_RET(ret == ACLNN_SUCCESS, ret);

        auto outParams = l0op::MatrixTransformRopeV2(
            params_.x_contiguous, params_.cos_contiguous, params_.sin_contiguous,
            params_.rotate_contiguous, l0Executor_);
        CHECK_RET(outParams != nullptr, ACLNN_ERR_INNER_NULLPTR);

        auto retView = l0op::ViewCopy(outParams, params_.out, l0Executor_);
        CHECK_RET(retView != nullptr, ACLNN_ERR_INNER_NULLPTR);

        *workspaceSize_ = uniqueExecutor->GetWorkspaceSize();
        uniqueExecutor.ReleaseTo(executor_);
        return ACLNN_SUCCESS;
    }

protected:
    std::string interfaceName_;
    MatrixTransformRopeV2ParamsBase params_;
    uint64_t *workspaceSize_;
    aclOpExecutor **executor_;
    aclOpExecutor *l0Executor_;
};

} // namespace matrix_transform_rope_v2

#endif // OP_HOST_OP_API_ACLNN_MATRIX_TRANSFORM_ROPE_V2_UTILS_H
