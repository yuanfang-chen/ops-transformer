/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include "matrix_transform_rope_v2.h"

namespace l0op {

const aclTensor *
MatrixTransformRopeV2(
    const aclTensor *x, const aclTensor *cos, const aclTensor *sin,
    const aclTensor *rotate,
    aclOpExecutor *executor) {

    // TODO: 实现算子逻辑
    L0_DFX(MatrixTransformRopeV2, x, cos, sin, rotate);

    auto xShape = x->GetViewShape();
    auto xDtype = x->GetDataType();
    auto xFormat = x->GetStorageFormat();

    // 创建输出tensor，shape与x保持一致
    auto output = executor->AllocTensor(xShape, xDtype, xFormat);

    auto ret = INFER_SHAPE(MatrixTransformRopeV2, OP_INPUT(x, cos, sin, rotate),
        OP_OUTPUT(output));
    OP_CHECK_INFERSHAPE(ret != ACLNN_SUCCESS, return nullptr,
        "MatrixTransformRopeV2 InferShape failed.");

    auto ret1 = ADD_TO_LAUNCHER_LIST_AICORE(MatrixTransformRopeV2,
        OP_INPUT(x, cos, sin, rotate),
        OP_OUTPUT(output));
    OP_CHECK_ADD_TO_LAUNCHER_LIST_AICORE(ret1 != ACLNN_SUCCESS, return nullptr,
        "MatrixTransformRopeV2 ADD_TO_LAUNCHER_LIST_AICORE failed.");

    return output;
}

} // namespace l0op
