/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <dlfcn.h>
#include <new>
#include <memory>
#include <unordered_map>
#include "aclnn_matrix_transform_rope_v2_utils.h"
#include "aclnn_matrix_transform_rope_v2_base_handler.h"
#include "aclnn_matrix_transform_rope_v2.h"
#include "aclnn_kernels/common/op_error_check.h"
#include "opdev/common_types.h"
#include "opdev/op_log.h"
#include "opdev/op_executor.h"
#include "opdev/platform.h"
#include "matrix_transform_rope_v2.h"

using namespace op;
using namespace matrix_transform_rope_v2;

/**
 * @brief HandlerFactory 类，用于根据 SOC 版本创建对应的 Handler
 */
class MatrixTransformRopeV2HandlerFactory {
private:
    std::unordered_map<NpuArch, std::unique_ptr<MatrixTransformRopeV2Handler>> handlers_;

public:
    void registerHandler(NpuArch npuArch, std::unique_ptr<MatrixTransformRopeV2Handler> handler)
    {
        handlers_[npuArch] = std::move(handler);
    }

    MatrixTransformRopeV2Handler *getHandler(NpuArch npuArch)
    {
        auto it = handlers_.find(npuArch);
        return it != handlers_.end() ? it->second.get() : nullptr;
    }
};

/**
 * @brief 公共处理函数，根据 SOC 版本路由到对应的 Handler
 */
static aclnnStatus aclnnMatrixTransformRopeV2GetWorkspaceSizeCommon(const char* interfaceName,
    MatrixTransformRopeV2ParamsBase &params, uint64_t *workspaceSize, aclOpExecutor **executor)
{
    MatrixTransformRopeV2HandlerFactory factory;
    auto npuArch = op::GetCurrentPlatformInfo().GetCurNpuArch();

    // 注册 DAV_2201 版本的 Handler
    factory.registerHandler(NpuArch::DAV_2201,
        std::make_unique<matrix_transform_rope_v2_base::MatrixTransformRopeV2BaseHandler>());

    // 获取当前 SOC 版本对应的 Handler
    if (auto *handler = factory.getHandler(npuArch)) {
        handler->Initialize(interfaceName, params, workspaceSize, executor);
        return handler->Process();
    } else {
        OP_LOGE(ACLNN_ERR_PARAM_INVALID, "%s: the soc version is not support", interfaceName);
    }

    return ACLNN_ERR_PARAM_INVALID;
}

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief aclnnMatrixTransformRopeV2 的第一段接口，根据具体的计算流程，计算 workspace 大小。
 * @domain aclnn_ops_infer
 *
 * @param [in] x: 输入tensor，shape为[B,N,S,D]/[B,S,N,D]/[S,B,N,D]，数据类型支持：BF16/FP16/FP32
 * @param [in] cos: 输入tensor，支持broadcast，数据类型支持：BF16/FP16/FP32
 * @param [in] sin: 输入tensor，支持broadcast，数据类型支持：BF16/FP16/FP32
 * @param [in] rotate: 输入tensor，shape为[D,D]，数据类型支持：BF16/FP16/FP32
 * @param [out] out: 输出tensor，shape与x保持一致，数据类型支持：BF16/FP16/FP32
 * @param [out] workspaceSize: 返回需要在 npu device 侧申请的 workspace 大小
 * @param [out] executor: 返回 op 执行器，包含了算子计算流程
 * @return aclnnStatus: 返回状态码
 */
aclnnStatus aclnnMatrixTransformRopeV2GetWorkspaceSize(
    const aclTensor *x, const aclTensor *cos, const aclTensor *sin,
    const aclTensor *rotate, const aclTensor *out,
    uint64_t *workspaceSize, aclOpExecutor **executor)
{
    OP_CHECK_COMM_INPUT(workspaceSize, executor);
    L2_DFX_PHASE_1(aclnnMatrixTransformRopeV2,
                    DFX_IN(x, cos, sin, rotate),
                    DFX_OUT(out));

    MatrixTransformRopeV2ParamsBase params =
        MatrixTransformRopeV2ParamsBuilder::Create(x, cos, sin, rotate, out).Build();

    return aclnnMatrixTransformRopeV2GetWorkspaceSizeCommon(__FUNCTION__, params, workspaceSize, executor);
}

/**
 * @brief aclnnMatrixTransformRopeV2 的第二段接口，执行算子计算。
 * @domain aclnn_ops_infer
 *
 * @param [in] workspace: 在 npu device 侧申请的 workspace 内存起址
 * @param [in] workspaceSize: 在 npu device 侧申请的 workspace 大小，由第一段接口获取
 * @param [in] executor: op 执行器，包含了算子计算流程
 * @param [in] stream: acl stream 流
 * @return aclnnStatus: 返回状态码
 */
aclnnStatus aclnnMatrixTransformRopeV2(void *workspace, uint64_t workspaceSize, aclOpExecutor *executor,
                             aclrtStream stream)
{
    L2_DFX_PHASE_2(aclnnMatrixTransformRopeV2);
    CHECK_COND(CommonOpExecutorRun(workspace, workspaceSize, executor, stream) == ACLNN_SUCCESS, ACLNN_ERR_INNER,
               "This is an error in MatrixTransformRopeV2 launch aicore");
    return ACLNN_SUCCESS;
}

#ifdef __cplusplus
}
#endif
