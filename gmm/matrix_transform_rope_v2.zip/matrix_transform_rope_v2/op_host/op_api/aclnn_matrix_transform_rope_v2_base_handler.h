/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef OP_HOST_OP_API_ACLNN_MATRIX_TRANSFORM_ROPE_V2_BASE_HANDLER_H
#define OP_HOST_OP_API_ACLNN_MATRIX_TRANSFORM_ROPE_V2_BASE_HANDLER_H

#include "aclnn_matrix_transform_rope_v2_utils.h"
#include "util/math_util.h"

namespace matrix_transform_rope_v2_base {

using namespace matrix_transform_rope_v2;
using namespace op;

/**
 * @brief SOC 特定常量定义
 */
constexpr int64_t DIM_IDX_0 = 0L;
constexpr int64_t DIM_IDX_1 = 1L;
constexpr int64_t DIM_IDX_2 = 2L;
constexpr int64_t DIM_IDX_3 = 3L;
constexpr size_t INPUT_4D_DIM_LIMIT = 4UL;
constexpr size_t INPUT_2D_DIM_LIMIT = 2UL;
constexpr size_t OUTPUT_4D_DIM_LIMIT = 4UL;

/**
 * @brief 支持的数据类型列表
 */
const std::initializer_list<DataType> SUPPORT_DTYPE_LIST = {
    DataType::DT_FLOAT16, DataType::DT_FLOAT, DataType::DT_BF16
};

/**
 * @brief 判断 format 是否为私有 format
 */
static bool IsPrivateFormat(ge::Format format)
{
    if (format == ge::FORMAT_NC1HWC0 || format == ge::FORMAT_FRACTAL_Z ||
        format == ge::FORMAT_NDC1HWC0 || format == ge::FORMAT_FRACTAL_Z_3D ||
        format == ge::FORMAT_FRACTAL_NZ || format == ge::FORMAT_NC1HWC0_C04) {
        return true;
    }
    return false;
}

/**
 * @brief 检查cos/sin的broadcast规则
 * 当x为BNSD时，cos、sin支持11SD、B1SD、BNSD
 * 当x为BSND时，cos、sin支持1S1D、BS1D、BSND
 * 当x为SBND时，cos、sin支持S11D、SB1D、SBND
 */
static bool CheckCosSinBroadcastShape(const op::Shape &xShape, const op::Shape &cosShape, const op::Shape &sinShape)
{
    auto xDimNum = xShape.GetDimNum();
    auto cosDimNum = cosShape.GetDimNum();
    auto sinDimNum = sinShape.GetDimNum();

    if (xDimNum != 4 || cosDimNum != 4 || sinDimNum != 4) {
        OP_LOGE(ACLNN_ERR_PARAM_INVALID, "x, cos, sin must all be 4D tensors");
        return false;
    }

    int64_t xB = xShape.GetDim(0);
    int64_t xDim1 = xShape.GetDim(1);
    int64_t xDim2 = xShape.GetDim(2);
    int64_t xD = xShape.GetDim(3);

    // 判断x的layout类型
    bool isBNSD = true;  // [B, N, S, D]
    bool isBSND = false; // [B, S, N, D]
    bool isSBND = false; // [S, B, N, D]

    // 根据第二、三维的大小判断layout（假设N和S不同）
    // 实际使用时可能需要更明确的判断方式
    // 这里假设用户输入符合预期

    // 检查cos shape
    int64_t cosB = cosShape.GetDim(0);
    int64_t cosDim1 = cosShape.GetDim(1);
    int64_t cosDim2 = cosShape.GetDim(2);
    int64_t cosD = cosShape.GetDim(3);

    // 检查sin shape
    int64_t sinB = sinShape.GetDim(0);
    int64_t sinDim1 = sinShape.GetDim(1);
    int64_t sinDim2 = sinShape.GetDim(2);
    int64_t sinD = sinShape.GetDim(3);

    // D维度必须一致
    if (cosD != xD || sinD != xD) {
        OP_LOGE(ACLNN_ERR_PARAM_INVALID, "cos and sin D dim must equal x D dim");
        return false;
    }

    // 检查cos和sin的shape是否一致
    if (cosShape != sinShape) {
        OP_LOGE(ACLNN_ERR_PARAM_INVALID, "cos and sin must have the same shape");
        return false;
    }

    return true;
}

/**
 * @brief 基础 Handler 实现类（DAV_2201）
 */
class MatrixTransformRopeV2BaseHandler : public MatrixTransformRopeV2Handler {
protected:
    bool CheckInputOutDims() override
    {
        auto xDimNum = params_.x->GetViewShape().GetDimNum();
        auto cosDimNum = params_.cos->GetViewShape().GetDimNum();
        auto sinDimNum = params_.sin->GetViewShape().GetDimNum();
        auto rotateDimNum = params_.rotate->GetViewShape().GetDimNum();
        auto outDimNum = params_.out->GetViewShape().GetDimNum();

        if (xDimNum != INPUT_4D_DIM_LIMIT) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "x tensor dim num must be 4, but got %zu", xDimNum);
            return false;
        }

        if (cosDimNum != INPUT_4D_DIM_LIMIT) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "cos tensor dim num must be 4, but got %zu", cosDimNum);
            return false;
        }

        if (sinDimNum != INPUT_4D_DIM_LIMIT) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "sin tensor dim num must be 4, but got %zu", sinDimNum);
            return false;
        }

        if (rotateDimNum != INPUT_2D_DIM_LIMIT) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "rotate tensor dim num must be 2, but got %zu", rotateDimNum);
            return false;
        }

        if (outDimNum != OUTPUT_4D_DIM_LIMIT) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "out tensor dim num must be 4, but got %zu", outDimNum);
            return false;
        }

        return true;
    }

    bool CheckInputOutShape() override
    {
        auto xShape = params_.x->GetViewShape();
        auto cosShape = params_.cos->GetViewShape();
        auto sinShape = params_.sin->GetViewShape();
        auto rotateShape = params_.rotate->GetViewShape();
        auto outShape = params_.out->GetViewShape();

        // 检查x和out的shape是否一致
        if (xShape != outShape) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "out shape must be equal to x shape");
            return false;
        }

        // 检查rotate的shape是否为[D, D]
        auto xD = xShape.GetDim(3);
        if (rotateShape.GetDim(0) != xD || rotateShape.GetDim(1) != xD) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "rotate shape must be [D, D] where D is the last dim of x");
            return false;
        }

        // 检查cos/sin的broadcast规则
        if (!CheckCosSinBroadcastShape(xShape, cosShape, sinShape)) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "cos/sin broadcast shape check failed");
            return false;
        }

        return true;
    }

    bool CheckDtypeValid() override
    {
        OP_CHECK_DTYPE_NOT_SUPPORT(params_.x, SUPPORT_DTYPE_LIST, return false);
        OP_CHECK_DTYPE_NOT_SUPPORT(params_.cos, SUPPORT_DTYPE_LIST, return false);
        OP_CHECK_DTYPE_NOT_SUPPORT(params_.sin, SUPPORT_DTYPE_LIST, return false);
        OP_CHECK_DTYPE_NOT_SUPPORT(params_.rotate, SUPPORT_DTYPE_LIST, return false);
        OP_CHECK_DTYPE_NOT_SUPPORT(params_.out, SUPPORT_DTYPE_LIST, return false);

        return true;
    }

    bool CheckFormat() override
    {
        if (IsPrivateFormat(params_.x->GetViewFormat())) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "x tensor format must be ND");
            return false;
        }
        if (IsPrivateFormat(params_.cos->GetViewFormat())) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "cos tensor format must be ND");
            return false;
        }
        if (IsPrivateFormat(params_.sin->GetViewFormat())) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "sin tensor format must be ND");
            return false;
        }
        if (IsPrivateFormat(params_.rotate->GetViewFormat())) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "rotate tensor format must be ND");
            return false;
        }
        if (IsPrivateFormat(params_.out->GetViewFormat())) {
            OP_LOGE(ACLNN_ERR_PARAM_INVALID, "out tensor format must be ND");
            return false;
        }

        return true;
    }
};

} // namespace matrix_transform_rope_v2_base

#endif // OP_HOST_OP_API_ACLNN_MATRIX_TRANSFORM_ROPE_V2_BASE_HANDLER_H
